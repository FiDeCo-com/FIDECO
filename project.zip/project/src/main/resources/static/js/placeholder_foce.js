$(function() {
	$("#login input").placeholder({
		// 커서를 이동할 때 힌트 표시가 나오도록 설정한다.
		force : true
	});
});